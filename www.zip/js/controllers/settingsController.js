tigoApp.controller('settingCtrl', ['$scope', function ($scope) {
	// Setting the window title
	$scope.windowTitle = "Settings";
	$scope.settings    = {msisdn : '208232832323'};
}])